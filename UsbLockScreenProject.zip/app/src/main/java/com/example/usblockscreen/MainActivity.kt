package com.example.usblockscreen

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

/**
 * Simple activity with a button to request Device Admin permission.
 * You only need to open this once after installing the app.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var compName: ComponentName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        compName = ComponentName(this, MyDeviceAdminReceiver::class.java)

        findViewById<Button>(R.id.btnEnableAdmin).setOnClickListener {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, compName)
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Allow this app to lock the screen automatically when the charger is connected."
                )
            }
            startActivity(intent)
        }
    }
}
