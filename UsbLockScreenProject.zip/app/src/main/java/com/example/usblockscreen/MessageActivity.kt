package com.example.usblockscreen

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Transparent activity that just shows the bottom message overlay.
 * It appears over the lock screen while the charger is connected.
 */
class MessageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val show = intent.getBooleanExtra("show", true)
        if (!show) {
            // Just close if we are called with show = false
            finish()
            return
        }

        setContentView(R.layout.message_overlay)
        // showWhenLocked & turnScreenOn flags are set in manifest via activity attributes
    }

    override fun onPause() {
        super.onPause()
        // Finish when not visible to avoid it lingering
        finish()
    }
}
