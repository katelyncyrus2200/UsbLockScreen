package com.example.usblockscreen

import android.app.admin.DeviceAdminReceiver

/**
 * Device Admin receiver; required so we can call DevicePolicyManager.lockNow().
 */
class MyDeviceAdminReceiver : DeviceAdminReceiver()
