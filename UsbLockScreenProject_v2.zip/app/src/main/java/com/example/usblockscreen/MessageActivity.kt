package com.example.usblockscreen

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MessageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val show = intent.getBooleanExtra("show", true)
        if (!show) {
            finish()
            return
        }

        setContentView(R.layout.message_overlay)
    }

    override fun onPause() {
        super.onPause()
        finish()
    }
}
