package com.example.usblockscreen

import android.app.admin.DeviceAdminReceiver

class MyDeviceAdminReceiver : DeviceAdminReceiver()
