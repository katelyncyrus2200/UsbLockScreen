package com.example.usblockscreen

import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent

class PowerReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {

        val action = intent.action

        if (Intent.ACTION_POWER_CONNECTED == action) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val comp = ComponentName(context, MyDeviceAdminReceiver::class.java)

            if (dpm.isAdminActive(comp)) {
                dpm.lockNow()
            } else {
                val activate = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
                    putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Enable this so the app can lock the screen when the charger is connected."
                    )
                }
                context.startActivity(activate)
            }

            val showIntent = Intent(context, MessageActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("show", true)
            }
            context.startActivity(showIntent)
        }

        if (Intent.ACTION_POWER_DISCONNECTED == action) {
            val hideIntent = Intent(context, MessageActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("show", false)
            }
            context.startActivity(hideIntent)
        }
    }
}
