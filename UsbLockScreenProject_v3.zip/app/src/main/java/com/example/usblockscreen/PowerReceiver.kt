package com.example.usblockscreen

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class PowerReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action

        if (Intent.ACTION_POWER_CONNECTED == action) {
            handlePowerConnected(context)
        } else if (Intent.ACTION_POWER_DISCONNECTED == action) {
            handlePowerDisconnected(context)
        }
    }

    private fun handlePowerConnected(context: Context) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val comp = ComponentName(context, MyDeviceAdminReceiver::class.java)

        if (dpm.isAdminActive(comp)) {
            // Lock the device
            dpm.lockNow()
        } else {
            // Ask user to enable device admin (will show next time they open the app)
            val adminIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(adminIntent)
        }

        // Show a lock-screen notification instead of overlay activity
        showUsbNotification(context)
    }

    private fun handlePowerDisconnected(context: Context) {
        // Remove the notification when USB is unplugged
        NotificationManagerCompat.from(context).cancel(NOTIF_ID)
    }

    private fun showUsbNotification(context: Context) {
        val nm = NotificationManagerCompat.from(context)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "USB Lock",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows when phone is locked due to USB being connected"
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Charger connected")
            .setContentText("Phone locked while USB is connected")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()

        nm.notify(NOTIF_ID, notification)
    }

    companion object {
        private const val CHANNEL_ID = "usb_lock_channel"
        private const val NOTIF_ID = 1001
    }
}
